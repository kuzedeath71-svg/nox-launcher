package com.nox.launcher

import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class NoxTheme(val name: String, val accent: Color, val subtitle: String)
private val noxThemes = listOf(
    NoxTheme("Dark Angel", Color(0xFFB8A7FF), "Silver wings · violet ash"),
    NoxTheme("Fallen Seraph", Color(0xFFC9C9D4), "Broken halo · cold silver"),
    NoxTheme("Abyss Knight", Color(0xFF8B9AA8), "Black steel · deep fog"),
    NoxTheme("Black Cathedral", Color(0xFFC4B9A7), "Ancient stone · candlelight"),
    NoxTheme("Eclipse", Color(0xFFB8A7FF), "Moon shadow · violet rim"),
    NoxTheme("Void Monarch", Color(0xFF9E91C8), "Obsidian crown"),
    NoxTheme("Grim Reaper", Color(0xFFB8BEC8), "Pale mist · iron"),
    NoxTheme("Blood Moon", Color(0xFFB65B68), "Muted crimson"),
    NoxTheme("Silver Oath", Color(0xFFD0D3DA), "Engraved silver"),
    NoxTheme("Raven", Color(0xFF9CA9C4), "Feather · midnight"),
    NoxTheme("Black Lotus", Color(0xFFB8A0B8), "Dark petals"),
    NoxTheme("Phantom", Color(0xFFA8B1C8), "Veil · smoke"),
    NoxTheme("Demon King", Color(0xFFB47B7B), "Cinder throne"),
    NoxTheme("Celestial Ruin", Color(0xFFC7C7D7), "Fallen heavens"),
    NoxTheme("Throne of Ash", Color(0xFFB8B1A5), "Ash and stone"),
    NoxTheme("Moonlit Knight", Color(0xFF9EBDD8), "Blue moonlight"),
    NoxTheme("Hollow Saint", Color(0xFFD0CCC4), "Cracked marble"),
    NoxTheme("Obsidian", Color(0xFF9FA4B4), "Polished black glass"),
    NoxTheme("Frozen Abyss", Color(0xFF9CCDDD), "Glacial blue"),
    NoxTheme("Nocturne", Color(0xFF929CCB), "Blue-black night"),
    NoxTheme("Dark Valkyrie", Color(0xFFC3B5D5), "Winged warrior"),
    NoxTheme("Angel of Ruin", Color(0xFFD1D0D8), "Pale wings"),
    NoxTheme("Cursed Crown", Color(0xFFB59AA8), "Broken royalty"),
    NoxTheme("Wraith", Color(0xFF9DA8B9), "Ghostly veil"),
    NoxTheme("Ebon Flame", Color(0xFFAA8AC9), "Violet ember"),
    NoxTheme("Gravekeeper", Color(0xFFA5A49F), "Grave fog"),
    NoxTheme("Frost Seraph", Color(0xFFB7D4E4), "Ice and silver"),
    NoxTheme("Blood Oath", Color(0xFFAC5964), "Crimson steel"),
    NoxTheme("Eternal Night", Color(0xFF9696B8), "No dawn"),
    NoxTheme("Last Archangel", Color(0xFFD0D1E0), "The final halo")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 8, 12)
        window.navigationBarColor = android.graphics.Color.rgb(7, 8, 12)
        setContent { NoxApp() }
    }
}

@Composable
private fun NoxApp() {
    val context = LocalContext.current
    var selectedTheme by remember { mutableIntStateOf(0) }
    var showDrawer by remember { mutableStateOf(false) }
    var showThemes by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var currentTime by remember { mutableStateOf(Date()) }
    var apps by remember { mutableStateOf(emptyList<ResolveInfo>()) }
    val theme = noxThemes[selectedTheme]
    val bg = Color(0xFF08090D)
    val panel = Color(0xAA171820)

    LaunchedEffect(Unit) {
        while (true) {
            currentTime = Date()
            delay(1000)
        }
    }
    LaunchedEffect(Unit) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = context.packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != context.packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(context.packageManager).toString().lowercase(Locale.getDefault()) }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = theme.accent, background = bg, surface = panel)) {
        Box(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF171721), bg, Color(0xFF0B0B10))))
        ) {
            // Subtle gothic-style lines, intentionally restrained rather than neon decoration.
            Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 22.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("N O X", color = Color(0xFFBFC0CC), fontSize = 12.sp, letterSpacing = 5.sp, fontWeight = FontWeight.Medium)
                    IconButton(onClick = { showThemes = true }) { Icon(Icons.Default.Settings, "Themes and settings", tint = Color.LightGray) }
                }
                Spacer(Modifier.height(42.dp))
                val time = SimpleDateFormat("HH\nmm", Locale.getDefault()).format(currentTime).split("\n")
                Column {
                    Text(time.getOrElse(0) { "--" }, fontSize = 76.sp, lineHeight = 72.sp, fontWeight = FontWeight.Light, color = theme.accent)
                    Text(time.getOrElse(1) { "--" }, fontSize = 76.sp, lineHeight = 72.sp, fontWeight = FontWeight.Light, color = Color(0xFFF0EFF5))
                    Spacer(Modifier.height(8.dp))
                    Text(SimpleDateFormat("EEE, dd MMM", Locale("id", "ID")).format(currentTime), color = Color(0xFFD0CFD8), fontSize = 14.sp)
                    Text("${theme.name}  ·  NOX Launcher", color = Color(0xFF888895), fontSize = 11.sp)
                }
                Spacer(Modifier.weight(1f))
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(color = panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().clickable { showDrawer = true }) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Search, null, tint = theme.accent)
                            Spacer(Modifier.width(10.dp))
                            Text("Search installed apps", color = Color(0xFFB9B8C4), fontSize = 14.sp)
                            Spacer(Modifier.weight(1f))
                            Text("↑", color = theme.accent, fontSize = 18.sp)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        apps.take(4).forEach { app ->
                            Surface(color = panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f).height(66.dp).clickable {
                                val launch = context.packageManager.getLaunchIntentForPackage(app.activityInfo.packageName)
                                if (launch != null) context.startActivity(launch)
                            }) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(app.loadLabel(context.packageManager).toString().take(10), color = Color.White, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                    Text("SWIPE UP OR TAP TO OPEN APP DRAWER", color = Color(0xFF73727F), fontSize = 9.sp, letterSpacing = 1.5.sp, modifier = Modifier.align(Alignment.CenterHorizontally).clickable { showDrawer = true }.padding(8.dp))
                }
            }

            if (showDrawer) {
                Surface(Modifier.fillMaxSize(), color = Color(0xF5090A0F)) {
                    Column(Modifier.fillMaxSize().padding(start = 22.dp, end = 16.dp, top = 24.dp, bottom = 16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("APPLICATIONS", color = Color.White, fontSize = 13.sp, letterSpacing = 3.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { showDrawer = false }) { Text("CLOSE", color = theme.accent) }
                        }
                        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), placeholder = { Text("Search apps", color = Color.Gray) }, singleLine = true)
                        val filtered = apps.filter { it.loadLabel(context.packageManager).toString().contains(query, true) }
                        Row(Modifier.fillMaxSize()) {
                            LazyColumn(Modifier.weight(1f)) {
                                val grouped = filtered.groupBy { it.loadLabel(context.packageManager).toString().firstOrNull()?.uppercaseChar() ?: '#' }.toSortedMap()
                                grouped.forEach { (letter, entries) ->
                                    item(key = "header_$letter") { Text(letter.toString(), color = theme.accent, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)) }
                                    items(entries, key = { it.activityInfo.packageName }) { app ->
                                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable {
                                            val launch = context.packageManager.getLaunchIntentForPackage(app.activityInfo.packageName)
                                            if (launch != null) context.startActivity(launch)
                                        }.padding(vertical = 11.dp, horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text(app.loadLabel(context.packageManager).toString(), color = Color(0xFFE7E6ED), fontSize = 15.sp)
                                        }
                                    }
                                }
                            }
                            Column(Modifier.width(22.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                (listOf("★") + ('A'..'Z').map { it.toString() }).forEach { letter ->
                                    Text(letter, color = theme.accent, fontSize = 10.sp, modifier = Modifier.padding(vertical = 2.dp).clickable { query = if (letter == "★") "" else letter })
                                }
                            }
                        }
                    }
                }
            }

            if (showThemes) {
                Surface(Modifier.fillMaxSize(), color = Color(0xF5090A0F)) {
                    Column(Modifier.fillMaxSize().padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("THEME ARCHIVE", color = Color.White, fontSize = 14.sp, letterSpacing = 3.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { showThemes = false }) { Text("DONE", color = theme.accent) }
                        }
                        Text("30 dark fantasy palettes", color = Color.Gray, fontSize = 12.sp)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 14.dp)) {
                            items(noxThemes) { item ->
                                val index = noxThemes.indexOf(item)
                                Surface(color = if (selectedTheme == index) Color(0xFF25242E) else Color(0xFF12131A), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().clickable { selectedTheme = index }) {
                                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(12.dp).clip(RoundedCornerShape(50)).background(item.accent))
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(item.name, color = Color.White, fontSize = 14.sp)
                                            Text(item.subtitle, color = Color.Gray, fontSize = 11.sp)
                                        }
                                        if (selectedTheme == index) Text("ACTIVE", color = item.accent, fontSize = 9.sp, letterSpacing = 1.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
